<?php return array('dependencies' => array(), 'version' => '86d4a80498fd21c04f00');
